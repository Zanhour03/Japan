document.getElementsByTagName("img")[0].src="img/bild3.jpg";

